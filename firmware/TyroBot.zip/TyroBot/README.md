# TyroBot
copyright :copyright: 2016 Tyro Electronics </br>
GPL General Public License 3.0</br>
http://tyroelectronics.com

## Build
Build your TyroBot by visiting:
http://tyroelectronics.com/build/
Or follow our video tutorial:
(coming soon)
## Code
Check out our library documentation:
http://tyroelectronics.com/docs/
## Repeat
Customize your TyroBot!(coming soon)

Special thanks to all of our kickstarter backers, especially Alex, Takashi Peluso, and Dimitris Platis!
